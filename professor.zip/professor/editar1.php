<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!--PACOTE DE FAVICON - ÍCONE DO SITE NAS ABAS DOS NAVEGADORES-->
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logosimples-logos-informatica.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="imagens/logosimples-logos-informatica.png" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">


    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Quadro Geral de Alunos</title>
    <style type="text/css">
        body {
            background: rgb(255, 105, 180);
            background: linear-gradient(90deg, rgba(255, 105, 180, 0.25) 50%, rgba(65, 105, 225, 0.5) 100%);
        }
        
        form {
            width: 40px;
            min-width: 350px;
            background: #FF69B4;
            box-shadow: 0 15px 30px white;
            margin: 100px auto;
            border-radius: 5px;
            padding-bottom: 5px;
            border: 2px solid midnightblue;
        }
        
        input,
        textarea {
            min-width: 120px;
            display: block;
            margin: 0 auto;
            border: 2px solid midnightblue;
            margin-top: 20px;
            height: 40px;
            padding-left: 10px;
            border-radius: 5px;
        }
        
        textarea {
            height: 100px;
            padding-top: 10px;
        }
        
        h1 {
            text-align: center;
        }
        
        button {
            display: block;
            margin: 10px auto;
            height: 40px;
            min-width: 200px;
            border: none;
            background-color: royalblue;
            color: white;
            cursor: pointer;
            border-radius: 10px;
        }
        
        button:hover {
            opacity: 0.4;
            background-color: green;
            color: white;
        }
        
        button:active {
            opacity: 0.6;
        }
    </style>

    </head>

<body>
<form method="get" action="editar2.php" style="background-color: #c8d5f8;">
Matricula do Aluno<br>
<input type="text" name="matricula"><br>
<button type="submit">Pesquisar</button>
    
</body>
</html>