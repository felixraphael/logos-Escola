
    <!--BARRA DE TOPO COM BOTÃO DE ACESSO AO MENU OCULTO-->
    <nav class="navbar bg-dark fixed-top">
        <div class="container-fluid">
            <!--Logotipo-->
            <a class="navbar-brand" href="#">
                <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">
            </a>
            <!--Título do portal de Gestão na parte central da barra de topo-->
            <a class="navbar-brand text-light fs-6" href="#">SGE - Sistema de Gestão Escolar</a>
            <!--Botão de acionamento do menu principal-->
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="text-light"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
          <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
        </svg> Menu</span>
      </button>

            <!--COLUNA LATERAL APÓS CLICAR NO BOTÃO MENU-->
            <div class="offcanvas offcanvas-end p-3 mb-2 bg-dark text-white" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu Principal - Professor</h5>
                    <button type="button" class="bg-dark text-white" data-bs-dismiss="offcanvas" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
</svg>
</button>
                </div>
                <div class="offcanvas-bod">
                    <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link active text-white" aria-current="page" href="painelAdmProf.php">Meu Painel - Professor</a>
                        </li>

                        <!--Acordeão-->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="offcanvasNavbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Gestão de Alunos
              </a>
                            <ul class="dropdown-menu" aria-labelledby="offcanvasNavbarDropdown">
                                <li><a class="dropdown-item" href="boletimProf.php">Boletim de notas</a></li>
                            </ul>
                        </li>

                        <li class="nav-item">
                            <button class="btn btn-outline-danger"><a class="nav-link text-white" aria-current="page" href="../index.php">Logoff</a></button>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <hr>

