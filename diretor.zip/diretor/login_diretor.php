<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!--PACOTE DE FAVICON - ÍCONE DO SITE NAS ABAS DOS NAVEGADORES-->
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logosimples-logos-informatica.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="imagens/logosimples-logos-informatica.png" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">


    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor"
        crossorigin="anonymous">

    <title>Área do Diretor - Login - Logos: a sua escola de profissões!</title>

</head>

<body>
    <!--ESTILO DO SITE-->
    <style type="text/css">
        body {
            background: rgb(255, 105, 180);
            background: linear-gradient(90deg, rgba(255, 105, 180, 0.25) 50%, rgba(65, 105, 225, 0.5) 100%);
        }

        form {
            width: 40px;
            min-width: 350px;
            background: #FF69B4;
            box-shadow: 0 15px 30px white;
            margin: 100px auto;
            border-radius: 5px;
            padding-bottom: 5px;
            border: 2px solid royalblue;
        }

        input,
        textarea {
            min-width: 120px;
            display: block;
            margin: 0 auto;
            border: 2px solid royalblue;
            margin-top: 20px;
            height: 40px;
            padding-left: 10px;
        }

        textarea {
            height: 100px;
            padding-top: 10px;
        }

        h1 {
            text-align: center;
        }

        button {
            display: block;
            margin: 20px auto;
            height: 40px;
            min-width: 320px;
            border: none;
            background-color: royalblue;
            color: silver;
            cursor: pointer;
            border-radius: 4px;
            border: 1px solid silver;
        }

        button:hover {
            opacity: 0.9;
            background-color: midnightblue;
            color: gold;
            border: 1px solid gold;
        }

        button:active {
            opacity: 0.9;
        }
    </style>

    <!--PHP Conecta-->
    <?php
    include('conecta.php');
    ?>

   <!--CARD INICIAL COM IMAGEM - SLOGAN DA INSTITUIÇÃO-->
   <div class="card bg-light text-dark w-100 p-1">
        <header class="bg-dark text-light bottom-0 end-0">
            <br>
            <table class="text-center text-light fs-4 p-4 w-100 align-items-center">

                <tr>
                    <td>
                        <a class="navbar-brand" href="#">
                            <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">
                        </a>
                    </td>
                </tr>

                <tr>
                    <td>

                        <p>
                            <strong>SGE</strong> - Área do Diretor
                        </p>

                    </td>

                </tr>

            </table>
        </header>
    </div>


    <!--FORMULÁRIO DE DADOS-->


    <form method="POST" action="painelAdmDiretor.php" style="background-color: #c8d5f8;">


        <input type="text" name="matricula" placeholder="Matricula do Diretor" required>
        <input type="text" name="senha" placeholder="senha" required>

        <button type="submit">Entrar</button>

    </form>


    <!--RODAPÉ DO SITE-->

    <?php
        include('rodape.php');
    ?>
        <!--JAVASCRIPT DO BOOTSTRAP-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js " integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2 "
            crossorigin="anonymous "></script>

</body>

</html>