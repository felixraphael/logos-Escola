<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Logos - A sua escola de profissões!</title>

    <!--PACOTE DE FAVICON - ÍCONE DO SITE NAS ABAS DOS NAVEGADORES-->
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logosimples-logos-informatica.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="imagens/logosimples-logos-informatica.png" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor"
        crossorigin="anonymous">
</head>

<body>



    <!--MENU-->
    <?php
    include('menudiretor.php');
    ?>

        <br>
        <br>
        <hr>


        <!--TÍTULO-->
        <div class="text-center">
            <h3>Meu Painel
                <span class="badge bg-primary">Diretoria</span>
            </h3>
        </div>

        <hr>

        <!--PAINEL - DIRETORIA -->
        <div class="card-group container-fluid w-75 text-center p-2">

            <div class="card p-2">
                <h3 class="card-title">Gestão de Alunos</h3>
                <a href="#">
                    <img src="imagens/boletim.jpg" class="card-img-top" alt="Boletim escolar">
                </a>

                <div class="card-body">


                    <div class="list-group">

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Gerar nova matrícula</h5>
                            </div>
                            <small>Utilize essa seção para matricular um aluno em um curso.</small>
                        </a>


                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Quadro geral de alunos</h5>
                            </div>
                            <small>Utilize essa seção para consultar os alunos matriculados nos cursos da instituição.</small>
                        </a>

                        <a href="buscar_alunos.php" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Busca refinada de alunos</h5>
                            </div>
                            <small>Utilize essa seção para pesquisar no sistema os dados dos alunos pela matrícula.</small>
                        </a>

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Consulta geral de boletins</h5>
                            </div>
                            <small>Utilize essa seção para consultar todos os boletins.</small>
                        </a>
                    </div>

                </div>

            </div>

            <div class="card p-2">
                <h3 class="card-title">Gestão de Professores</h3>
                <a href="#">
                    <img src="imagens/professores.jpg" class="card-img-top" alt="Boletim escolar">
                </a>

                <div class="card-body">


                    <div class="list-group">

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Registrar novo professor</h5>
                            </div>
                            <small>Utilize essa seção para cadastrar um novo docente.</small>
                        </a>


                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Consultar quadro de professores</h5>
                            </div>
                            <small>Utilize essa seção para consultar a relação completa de professores registrados na instituição.</small>
                        </a>

                        <a href="painelAdmProf.php" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Acessar sistema como professor</h5>
                            </div>
                            <small>Utilize essa seção para acessar o sistema utilizando um perfil de professor.</small>
                        </a>

                    </div>

                </div>

            </div>

            <div class="card p-2">
                <h3 class="card-title">Gestão de Disciplinas</h3>
                <a href="#">
                    <img src="imagens/disciplinas.jpg" class="card-img-top" alt="Boletim escolar">
                </a>

                <div class="card-body">


                    <div class="list-group">

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Cadastrar novas disciplinas</h5>
                            </div>
                            <small>Utilize essa seção para registrar uma nova disciplina.</small>
                        </a>


                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Consultar catálogo de disciplinas</h5>
                            </div>
                            <small>Utilize essa seção para consultar as disciplinas ofertadas pela instituição.</small>
                        </a>

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Cadastrar novas disciplinas</h5>
                            </div>
                            <small>Utilize essa seção para registrar uma nova disciplina</small>
                        </a>
                    </div>

                </div>

            </div>


        </div>


        <!--RODAPÉ DO SITE-->
        <?php
    include('rodape.php');
    ?>

            <!-- JavaScript Bundle with Popper -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
                crossorigin="anonymous"></script>
</body>

</html>